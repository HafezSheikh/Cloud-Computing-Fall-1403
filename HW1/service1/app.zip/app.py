import psycopg2

from flask import Flask



app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World'


@app.route('/requestService')
def requestService():
    return 'Hello World'


@app.route('/trackRequest')
def trackRequest():
    return 'Hello World'



# main driver function
if __name__ == '_apt install python3.10-venv_main__':

    app.run()

@app.route('/createDatabase')
def database():
    email = "hafezsheikh@gmail.com"
    status = "pending"

    conn = psycopg2.connect(
        host="cchw1-9931097",
        database="cchw1-9931097",
        user="root",
        password="nRocULwUkiK3sVS3QedxqYKw")

    cur = conn.cursor()
    cur.execute("""DROP TABLE IF EXISTS requests;""")
    cur.execute("""
                CREATE TABLE requests (id SERIAL PRIMARY KEY,
                            email varchar (150) NOT NULL,
                            status varchar (50) NOT NULL,
                            imageCaption varchar (200),
                            newImageURL varchar (300),
                            date_added date DEFAULT CURRENT_TIMESTAMP);
                            """)




    cur.execute("""INSERT INTO requests (email, status)
            VALUES (%s, %s);""",
            (email,
             status,
             )
            )
    


    conn.commit()

    cur.close()
    conn.close()
    return "done"
